package org.buffer.adaptablebottomnavigation.model;

public class ItemInfo {
    public Object object;
    public int position;
}
